// const dotenv = require("dotenv");
// dotenv.config({ path: path.resolve(__dirname, "../../.env") });

// const app = require("./index");
// const serverless = require('serverless-http');

// module.exports.handler = serverless(app);